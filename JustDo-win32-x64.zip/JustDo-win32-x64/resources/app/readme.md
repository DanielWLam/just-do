# Accompanying repository for the Electron guide

![Sound Machine](https://rawgithub.com/bojzi/sound-machine/master/sketch/sound-machine.png)